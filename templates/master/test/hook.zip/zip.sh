#! /bin/bash
zip -r -q ../hook.zip .
