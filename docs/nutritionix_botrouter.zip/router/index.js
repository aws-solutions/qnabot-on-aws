const axios = require('axios');
const SUCCESS = 'success';
const FAILED = 'failed';

function defaultResponseObject() {
    return {
        response: "message",
        status: SUCCESS,
        message: "",
        messageFormat: "PlainText",
        sessionAttributes: {
            appContext: {
                altMessages: {
                    ssml: undefined,
                    markdown: undefined
                }
            }
        }
    }
}

function createDefaultResp() {
    let result = {
        valueCalcium: 0,
        valueCalories: 0,
        valueCholesterol: 0,
        valueFatCalories: 0,
        valueFibers: 0,
        valueIron: 0,
        valueProteins: 0,
        valueSatFat: 0,
        valueSodium: 0,
        valueSugars: 0,
        valueTotalCarb: 0,
        valueTotalFat: 0,
        valueTransFat: 0,
        valueVitaminA: 0,
        valueVitaminC: 0,
        valueVitaminD: 0,
        valuePotassium_2018: 0,
        valueFoodNames: undefined
    };
    return result;
}

function getAttribute(attr_id, food) {
    let res = 0;
    food.full_nutrients.forEach((nutrient) => {
        if (nutrient.attr_id === attr_id) {
            res = nutrient.value;
        }
    });
    return res;
}

function isString(val) {
    return ( (typeof val === 'string' || val instanceof String) ? true : false);
}

function createSummaryData(resp) {
    let result = createDefaultResp();
    resp.foods.forEach((food) => {
        result.valueCalcium += getAttribute(301, food); // from 301
        result.valueCalories += food.nf_calories;
        result.valueCholesterol += food.nf_cholesterol;
        result.valueFatCalories += food.nf_total_fat;
        result.valueFibers += getAttribute(291, food); // from 291
        result.valueIron += getAttribute(303, food); // from 303
        result.valueProteins += food.nf_protein;
        result.valueSatFat += food.nf_saturated_fat;
        result.valueSodium += food.nf_sodium;
        result.valueSugars += food.nf_sugars;
        result.valueTotalCarb += food.nf_total_carbohydrate;
        result.valueTotalFat += food.nf_total_fat;
        result.valueTransFat += getAttribute(605, food); // from 605
        result.valueVitaminA += (getAttribute(320, food) + getAttribute(318,food)); // from 320 + 318
        result.valueVitaminC += getAttribute(401, food); // from 401
        result.valueVitaminD += getAttribute(324, food); // from 324
        result.valuePotassium_2018 += getAttribute(306, food); // from 306
        result.valueFoodNames = result.valueFoodNames ? result.valueFoodNames +', ' + food.food_name : food.food_name;
    });
    const keys = Object.keys(result);
    for (const key of keys) {
        const val = result[key];
        result[key] = isString(val) ? val : val.toFixed(2);
    }
    return result;
}

async function callNutritionix(inputText) {
    const postData = {
        "query": inputText,
        "timezone": "Americas/Denver"
    };

    const axiosConfig = {
        headers: {
            'Content-Type': 'application/json',
            'x-app-id': process.env.xAppId,
            'x-app-key': process.env.xAppKey
        }
    };

    try {
        console.log("Calling via axios");
        console.log("Post Data: " + JSON.stringify(postData,null,2));
        console.log("Axios Config: " + JSON.stringify(axiosConfig, null, 2));
        let res = await axios.post('https://trackapi.nutritionix.com/v2/natural/nutrients', postData, axiosConfig)
        console.log("RESPONSE RECEIVED: ", JSON.stringify(res.data, null, 2));

        // calculate summary data
        let summaryData = createSummaryData(res.data);
        console.log("SUMMARY DATA: " + JSON.stringify(summaryData, null, 2));
        return summaryData;
    } catch(err) {
        console.log("ERROR: " + err);
        return ({Error: `Failed to determine nutrition content. ${err}`});
    }
}

function formatAsTable(data) {
    let result = "| Name        | Quantity |\n";
    result += "| ------------- |-------------:|\n";
    Object.keys(data).forEach(function (key) {
        const value = data[key];
        result += "|" + key + " | " + value + "\n";
    });
    return result;
}

function doRequest(event) {
    return new Promise(async function(resolve, reject) {
        let respObj = defaultResponseObject();
        try {
            let data = await callNutritionix(event.req.inputText);
            respObj.message = JSON.stringify(data);
            respObj.sessionAttributes.appContext.altMessages.ssml = `<speak> results </speak>`;
            respObj.sessionAttributes.appContext.altMessages.markdown = (data.Error) ? data.Error : formatAsTable(data);
            resolve(respObj);
        } catch (err) {
            respObj.message = "Error determining response:" + err;
            respObj.status = FAILED;
            respObj.sessionAttributes.appContext.altMessages.ssml = `<speak> Error determining response </speak>`;
            respObj.sessionAttributes.appContext.altMessages.markdown = `**Error determining response** \n ${err}`;
            resolve(respObj);
        }
    });
}

exports.lambdaHandler = async (event, context) => {
    console.log('event start data:' + JSON.stringify(event,null,2));
    return await doRequest(event);
};
